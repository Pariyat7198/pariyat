
import os
from app.app import app, db, User


def setup_module(module):
    with app.app_context():
        db.drop_all()
        db.create_all()


def test_signup_login():
    client = app.test_client()
    # Signup
    resp = client.post('/signup', data={
        'username': 'testuser',
        'email': 'test@example.com',
        'password': 'secret'
    }, follow_redirects=True)
    assert resp.status_code == 200

    # Logout
    client.get('/logout', follow_redirects=True)

    # Login
    resp = client.post('/login', data={
        'username': 'testuser',
        'password': 'secret'
    }, follow_redirects=True)
    assert resp.status_code == 200


def test_create_post():
    client = app.test_client()
    # Ensure logged in
    client.post('/login', data={'username': 'testuser', 'password': 'secret'}, follow_redirects=True)
    # Create post
    resp = client.post('/post', data={'content': 'Hello world!'}, follow_redirects=True)
    assert resp.status_code == 200
