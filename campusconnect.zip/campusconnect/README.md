
# CampusConnect — Simple Social Media Clone (Flask)

A beginner-friendly social app for BCA final-year projects. Features sign-up/login, posts with images, likes, comments, follow/unfollow, and a personalized feed.

## Tech Stack
- Backend: Flask, SQLAlchemy, Flask-Login
- DB: SQLite (file-based)
- Frontend: Bootstrap 5 + Jinja2
- Storage: Local `uploads/` folder
- Deployment: Render/Heroku/PythonAnywhere

## Features
- User authentication (signup/login/logout)
- Create text/image posts
- Like & comment on posts
- Follow/unfollow users
- Personalized feed (followed users + self)

## Quick Start
```bash
# 1) Create a virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 2) Install dependencies
pip install -r requirements.txt

# 3) Run the app
python app/app.py
# Visit http://127.0.0.1:5000
```

## Environment Variables (optional)
- `SECRET_KEY` — session secret (default: `change-this`)
- `DATABASE_URL` — SQLAlchemy URL (default: `sqlite:///campusconnect.db`)

## Deployment (Render)
1. Push to GitHub
2. Create new Web Service
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app.app:app`
5. Set `SECRET_KEY` in environment

## Tests (starter)
Use `pytest` + Flask test client (add later).

## Roadmap
- Pagination & infinite scroll
- Edit/Delete posts
- Profile pictures
- Hashtags & search
- Switch to PostgreSQL

## License
MIT


### Run tests

```bash
pytest -q
```
